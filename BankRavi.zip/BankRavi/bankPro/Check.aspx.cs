﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;
using System.Configuration;
namespace bankPro
{
    public partial class Check : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Ensure the account number is stored in the session
                if (Session["AccountNumber"] != null)
                {
                    string accountNumber = Session["AccountNumber"].ToString();
                    try
                    {
                        // Fetch balance using the helper method
                        decimal initialBalance = GetInitialBalance(accountNumber);

                        // Update labels with retrieved balance
                        lblTotalBalance.Text = "Total Balance is:";
                        lblInitialBalance.Text = initialBalance.ToString("C"); // Format as currency
                    }
                    catch (Exception ex)
                    {
                        // Handle and display errors
                        lblTotalBalance.Text = "Error:";
                        lblInitialBalance.Text = ex.Message;
                    }
                }
                else
                {
                    // Handle missing session variable
                    lblTotalBalance.Text = "Error:";
                    lblInitialBalance.Text = "Account number not found. Please log in again.";
                }
            }
        }

        /// <summary>
        /// Retrieves the balance for a given account number from the database.
        /// </summary>
        private decimal GetInitialBalance(string accountNumber)
        {
            decimal balance = 0;

            // Define your database connection string
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ConnectionString;
            // SQL query to fetch the balance
            string query = "SELECT InitialBalance FROM Customers WHERE AccountNumber = @AccountNumber";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameter to prevent SQL injection
                    command.Parameters.AddWithValue("@AccountNumber", accountNumber);

                    try
                    {
                        connection.Open(); // Open the database connection
                        object result = command.ExecuteScalar(); // Execute the query

                        // Check if a result is returned
                        if (result != null && decimal.TryParse(result.ToString(), out balance))
                        {
                            return balance;
                        }
                        else
                        {
                            throw new Exception("Account not found or no balance available.");
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Database error: " + ex.Message);
                    }
                }
            }
        }
    }
}