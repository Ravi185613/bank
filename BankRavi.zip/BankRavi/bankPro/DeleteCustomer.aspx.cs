﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
namespace bankPro
{
    public partial class DeleteCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            // Retrieve entered Account Number
            string accountNumber = txtAccountNumber.Text;

            // Connection string
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // SQL Query to delete customer data
                    string query = "DELETE FROM Customers WHERE AccountNumber = @AccountNumber";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // Display success message
                            lblMessage.Text = "Customer account deleted successfully.";
                            lblMessage.ForeColor = System.Drawing.Color.LightGreen;
                        }
                        else
                        {
                            // Display message if account not found
                            lblMessage.Text = "No customer found with the provided account number.";
                            lblMessage.ForeColor = System.Drawing.Color.Yellow;
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Display error message
                    lblMessage.Text = "Error: " + ex.Message;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}