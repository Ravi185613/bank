﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace bankPro
{
    public partial class Customer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
            btnNext.Visible = false;
            btnBack.Visible = false;
        }

        protected void btnCheck_Click(object sender, EventArgs e)
        {
            string accountNumber = txtAccountNumber.Text.Trim(); // Retrieve account number
            string password = txtPassword.Text.Trim(); // Retrieve password

            if (string.IsNullOrEmpty(accountNumber) || string.IsNullOrEmpty(password))
            {
                lblMessage.Text = "Please enter both account number and password.";
                lblMessage.Visible = true;
                return;
            }

            // Save account number in session to use it later
            Session["AccountNumber"] = accountNumber;

            // Connection string
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM Customers WHERE AccountNumber = @AccountNumber AND Password = @Password";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@AccountNumber", accountNumber);
                cmd.Parameters.AddWithValue("@Password", password);

                conn.Open();
                int count = (int)cmd.ExecuteScalar();
                conn.Close();

                if (count > 0) // Account and password match
                {
                    lblMessage.Text = "Account exists.";
                    lblMessage.CssClass = "success-message"; // Apply success style
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Visible = true;

                    btnNext.Visible = true; // Show "Next" button
                }
                else // Invalid account number or password
                {
                    lblMessage.Text = "Invalid account number or password.";
                    lblMessage.CssClass = "error-message"; // Apply error style
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Visible = true;

                    btnBack.Visible = true; // Show "Back" button
                }
            }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            // Redirect to CustomerM.aspx
            Response.Redirect("CustomerM.aspx");
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            // Redirect back to Index.aspx
            Response.Redirect("index.aspx");
        }
    }
}