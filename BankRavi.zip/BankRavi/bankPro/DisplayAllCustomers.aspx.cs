﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Configuration;
namespace bankPro
{
    public partial class DisplayAllCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCustomerData();
            }
        }

        protected void BackButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Banker.aspx");
        }

        private void LoadCustomerData()
        {
            // Connection string
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // SQL query to retrieve customer data including Password
                    string query = "SELECT AccountNumber, CustomerName, InitialBalance, Password FROM Customers";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Bind data to GridView
                            GridViewCustomers.DataSource = dataTable;
                            GridViewCustomers.DataBind();
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Display error message
                    Response.Write("Error: " + ex.Message);
                }
            }
        }
    }
}
