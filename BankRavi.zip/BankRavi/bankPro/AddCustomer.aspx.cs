﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Configuration;

namespace bankPro
{
    public partial class AddCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // Retrieve entered details 
            string accountNumber = txtAccountNumber.Text;
            string customerName = txtCustomerName.Text;
            string initialBalance = txtInitialBalance.Text;
            string password = txtPassword.Text; // Retrieve the password entered by the user

            // Connection string
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // SQL query to insert customer data
                    string query = "INSERT INTO Customers (AccountNumber, CustomerName, InitialBalance, Password) VALUES (@AccountNumber, @CustomerName, @InitialBalance, @Password)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);
                        command.Parameters.AddWithValue("@CustomerName", customerName);
                        command.Parameters.AddWithValue("@InitialBalance", initialBalance);
                        command.Parameters.AddWithValue("@Password", password); // Save the password directly

                        command.ExecuteNonQuery();
                    }
                    // Display success message
                    lblMessage.Text = "Customer account added successfully.";
                    lblMessage.ForeColor = System.Drawing.Color.LightGreen;
                }
                catch (Exception ex)
                {
                    // Display error message
                    lblMessage.Text = "Error: " + ex.Message;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}